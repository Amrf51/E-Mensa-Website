@extends("layouts.layout")

@section("content")
<h1>Nicht implementiert</h1>
<p>Sie haben eine <abbr title="Pfad: {{$url}}">Action</abbr> aufgerufen, die zu dieser <abbr title="views/notimplemented.blade.php">View</abbr> führt.</p>
<p>Vervollständigen Sie die Action, sodass die Aufgabe erfüllt wird.</p>
@endsection