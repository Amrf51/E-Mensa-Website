<?php
?>

        <!DOCTYPE html>
<html lang="de">
<head>
    <title>Page 1</title>
</head>
<body>

<p>Der Wert von ?name lautet: {{$data}}</p>
</body>
</html>

