
        <!DOCTYPE html>
<html lang="de">
<head>
    <title>@yield('title')</title>
</head>
<body>

@yield('header')


@yield('main')


@yield('footer')


</body>
</html>