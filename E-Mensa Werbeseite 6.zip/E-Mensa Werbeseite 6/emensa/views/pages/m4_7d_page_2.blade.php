<?php
?>

        <!DOCTYPE html>
<html lang="de">
<head>
    <title>Page 2</title>
</head>
<body>

@extends('examples.layout.m4_7d_layout')

@section('header')
    <p>Header Page 2</p>
@endsection

@section('main')
    <p>Main Page 2</p>
@endsection

@section('footer')
    <p>Footer Page 2</p>
@endsection

</body>
</html>
